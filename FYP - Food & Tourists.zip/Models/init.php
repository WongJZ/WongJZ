<?php
// init.php - Centralized session and config handling
require_once "Models/config.php";
?>