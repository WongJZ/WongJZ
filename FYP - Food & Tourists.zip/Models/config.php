<?php

// Database configuration
$host = "localhost";
$dbname = "fnt_db"; // Your database name
$username = "root"; // Change if necessary
$password = ""; // Change if necessary

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    global $pdo;
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Google OAuth Configuration
require_once 'vendor/autoload.php';

//$googleClient = new Google_Client();
//$googleClient->setClientId("YOUR_GOOGLE_CLIENT_ID");
//$googleClient->setClientSecret("YOUR_GOOGLE_CLIENT_SECRET");
//$googleClient->setRedirectUri("http://localhost:81/FYP%20-%20Food%20&%20Tourists/Controllers/google-callback.php");
//$googleClient->addScope("email");
//$googleClient->addScope("profile");
?>
