<?php
require_once "Models/config.php";

if (isset($_GET["code"])) {
    $token = $googleClient->fetchAccessTokenWithAuthCode($_GET["code"]);

    if (!isset($token["error"])) {
        $googleClient->setAccessToken($token["access_token"]);
        $google_oauth = new Google_Service_Oauth2($googleClient);
        $google_account_info = $google_oauth->userinfo->get();

        $email = $google_account_info->email;
        $name = $google_account_info->name;

        // Check if user exists in database
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user) {
            // Register new Google user
            $stmt = $pdo->prepare("INSERT INTO users (email, password) VALUES (?, '')");
            $stmt->execute([$email]);
            $user_id = $pdo->lastInsertId();
        } else {
            $user_id = $user["id"];
        }

        $_SESSION["user_id"] = $user_id;
        $_SESSION["email"] = $email;

        header("Location: index.php");
        exit;
    }
}

header("Location: login.php");
exit;
?>
