<?php
$view = new stdClass();
// Create a new instance of stdClass to serve as a container for data to be used in the view

$view->pageTitle = 'Search Results';
// Set the pageTitle property of the view object to 'Homepage', which will be utilized by the template to display the page title

require('Views/Global/header.phtml');
// Include the header template which contains the opening HTML tags and navigation

require_once('Views/Guest/search.phtml');
// Include the 'index.phtml' template file. This file will use the $view object to render the 'Homepage' page

require('Views/Global/footer.phtml');
// Include the footer template which contains the closing HTML tags
?>
